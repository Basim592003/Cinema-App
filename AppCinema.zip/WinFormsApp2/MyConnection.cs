﻿using System;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Text;
using System.Configuration;

namespace WinFormsApp2
{
    class MyConnection
    {
        public SqlConnection con;
        public MyConnection()
        {
            con = new SqlConnection(ConfigurationManager.ConnectionStrings["CC"].ConnectionString);
        }
    }
}
