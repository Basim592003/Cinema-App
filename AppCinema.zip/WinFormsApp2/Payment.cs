﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.IO;

namespace WinFormsApp2
{
    public partial class Payment : Form
    {
        public bool PaymentSuccessful { get; set; }
        int monthInt;
        int yearInt;


        public Payment()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(string.IsNullOrEmpty(textBox1.Text) || string.IsNullOrEmpty(textBox2.Text) || string.IsNullOrEmpty(textBox3.Text) || string.IsNullOrEmpty(textBox4.Text))
            {
                MessageBox.Show("Please enter your card details to reserve a seat");
            }
            else
            {
                if (string.IsNullOrEmpty(textBox1.Text) || textBox1.Text.Length != 16)
                {
                    MessageBox.Show("Please enter a valid card number");
                }


                if (string.IsNullOrEmpty(textBox2.Text) || textBox2.Text.Length != 2 || textBox2.Text.Length < 2)
                {
                    MessageBox.Show("Please enter a valid month date");
                    clearMonth();
                }


                else
                {
                    string month = textBox2.Text.Substring(0, 2);
                    if (!int.TryParse(month, out monthInt) || monthInt < 1 || monthInt > 12)
                    {
                        MessageBox.Show("Please enter a valid expiration date");
                        clearMonth();
                    }
                }



                if (string.IsNullOrEmpty(textBox4.Text) || textBox4.Text.Length != 2 || textBox4.Text.Length < 2)
                {
                    MessageBox.Show("Please enter a valid year");
                    clearYear();
                }


                else
                {
                    string year = textBox4.Text.Substring(0, 2);
                    if (!int.TryParse(year, out yearInt) || yearInt < 23 || yearInt > 33)
                    {
                        MessageBox.Show("Please enter a valid expiration date");
                        clearYear();
                    }
                }


                if (string.IsNullOrEmpty(textBox3.Text) || textBox3.Text.Length != 3)
                {
                    MessageBox.Show("Please enter a valid CVV");
                }

                if (textBox1.Text.Length == 16 &&
                    textBox2.Text.Length == 2 &&
                    textBox4.Text.Length == 2 &&
                    textBox3.Text.Length == 3 &&
                    monthInt >= 1 && monthInt <= 12
                    && yearInt >= 23 && yearInt <= 33)
                {
                    PaymentSuccessful = true;
                    this.Close();
                }
            }
          
           

        }

        void clearMonth()
        {
            textBox2.Text = "";
        }
        
        void clearYear()
        {
            textBox4.Text = "";
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsNumber(e.KeyChar))
            {
                e.Handled = true;
            }

            if (textBox1.Text.Length >= 16 && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void textBox2_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsNumber(e.KeyChar))
            {
                e.Handled = true;
            }

            if (textBox2.Text.Length >= 2 && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void textBox3_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsNumber(e.KeyChar))
            {
                e.Handled = true;
            }

            if (textBox3.Text.Length >= 3 && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void textBox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsNumber(e.KeyChar))
            {
                e.Handled = true;
            }

            if (textBox4.Text.Length >= 2 && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }
    }
}
