﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.IO;
using System.Windows.Forms;


namespace WinFormsApp2
{
    public partial class BookTime : Form
    {
        public readonly List<Seat> _seats;
        private readonly int _identifier;

        public BookTime(int identifier)
        {
            InitializeComponent();
            _identifier = identifier;

            string seatFile = string.Format("ReservedSeats_{0}.txt", identifier);
            string path = Path.Combine(Directory.GetCurrentDirectory(), seatFile);

            _seats = LoadSeatsFromFile(path);
            //_seats = new List<Seat>();

            if (_seats.Count == 0)
            {
                for (int i = 0; i < 9; i++)
                {
                    _seats.Add(new Seat(i / 3, i % 3, true));
                }
            }

            // Add buttons for each seat to the grid layout
            for (int i = 0; i < _seats.Count; i++)
            {
                var seat = _seats[i];
                var button = new Button
                {

                    Text = string.Format("{0}{1}", (char)('A' + seat.Row), seat.Column + 1),
                    Tag = seat,
                    Enabled = seat.IsAvailable
                };
                button.Size = new Size(100, 50);
                button.Click += SeatButton_Click;
                seatGrid.Controls.Add(button);
            }
        }

 

        private void SeatButton_Click(object sender, EventArgs e)
        {
            Payment pt = new Payment();
            pt.ShowDialog();

            if (pt.PaymentSuccessful)
            {
                var button = (Button)sender;
                var seat = (Seat)button.Tag;
                if (seat.IsAvailable)
                {
                    seat.IsAvailable = false;
                    button.Enabled = false;


                    string fileName = string.Format("ReservedSeats_{0}.txt", _identifier);
                    string path = Path.Combine(Directory.GetCurrentDirectory(), fileName);

                    SaveSeatsToFile(_seats, path);
                    MessageBox.Show("Thank you for your purchase! Your ticket for seat " + button.Text + " has been reserved.");
                }
                this.Close();
            }


        }

        public void SaveSeatsToFile(IEnumerable<Seat> seats, string filePath)
        {
            using (var writer = new StreamWriter(filePath))
            {
                foreach (var seat in seats)
                {
                    writer.WriteLine("{0},{1},{2}", seat.Row, seat.Column, seat.IsAvailable ? "available" : "reserved");
                }
            }
        }

        private List<Seat> LoadSeatsFromFile(string filePath)
        {
            var seats = new List<Seat>();

            if (File.Exists(filePath))
            {
                using (var reader = new StreamReader(filePath))
                {
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        var parts = line.Split(',');
                        var row = int.Parse(parts[0]);
                        var column = int.Parse(parts[1]);
                        var isAvailable = parts[2] == "available";
                        seats.Add(new Seat(row, column, isAvailable));
                    }
                }
            }

            return seats;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
