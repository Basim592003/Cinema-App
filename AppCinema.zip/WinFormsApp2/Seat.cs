﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WinFormsApp2
{
    public class Seat
    {
        public int Row { get; set; }
        public int Column { get; set; }
        public bool IsAvailable { get; set; }

        public Seat(int row, int column, bool isAvailable)
        {
            Row = row;
            Column = column;
            IsAvailable = isAvailable;
        }
    }
}
