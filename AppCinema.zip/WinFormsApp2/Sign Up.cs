﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;



namespace WinFormsApp2
{
    public partial class Sign_Up : Form
    {
       
        //SqlConnection con = new SqlConnection(@"Data Source = LAPTOP-5JS3KV1P\SQLEXPRESS;Initial Catalog=Role_DB;Integrated Security=True;");
        //SqlCommand cmd;
        MyConnection db = new MyConnection();

        public Sign_Up()
        {
            InitializeComponent(); 
        }

        private void Save_Click(object sender, EventArgs e)
        {
           
            if (nameBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "" || textBox4.Text == "")
            {
                MessageBox.Show("None of the fields can be empty");
            }
            else if (textBox3.Text != textBox4.Text)
            {
                MessageBox.Show("The passwords do not match");
            }
            else
            {
                using (db.con)
                {
                    db.con.Open();
                    SqlCommand cmd = new SqlCommand("UserAdd", db.con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@name", nameBox1.Text.Trim());
                    cmd.Parameters.AddWithValue("@username", textBox2.Text.Trim());
                    cmd.Parameters.AddWithValue("@password", textBox3.Text.Trim());

                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Registration is successfull");
                    //Form1 f = new Form1();
                    //f.Show();
                    this.Close();
                   
                }

            }


        }

        private void backbutton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void nameBox1_Validating(object sender, CancelEventArgs e)
        {

            if (string.IsNullOrWhiteSpace(nameBox1.Text))
            {
                errorProvider1.SetError(nameBox1, "This field cannot be empty");
                e.Cancel = false;
            }
            else
            {

                errorProvider1.SetError(nameBox1, "");
            }

        }

        private void textBox2_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox2.Text))
            {
                errorProvider1.SetError(textBox2, "This field cannot be empty");
                e.Cancel = false;
            }
            else
            {

                errorProvider1.SetError(textBox2, "");
            }
        }

        private void textBox3_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox3.Text))
            {
                errorProvider1.SetError(textBox3, "This field cannot be empty");
                e.Cancel = false;
            }
            else
            {

                errorProvider1.SetError(textBox3, "");
            }
        }

        private void textBox4_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox4.Text))
            {
                errorProvider1.SetError(textBox4, "This field cannot be empty");
                e.Cancel = false;
            }
            else
            {

                errorProvider1.SetError(textBox4, "");
            }
        }
    }
}
