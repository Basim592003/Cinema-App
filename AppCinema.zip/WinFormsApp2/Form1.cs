﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace WinFormsApp2
{
    public partial class Form1 : Form
    {
      
        MyConnection db = new MyConnection();

        public Form1()
        {
            InitializeComponent();
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            try
            {
                if (textBox1.Text == "" && textBox2.Text == "")
                {
                    MessageBox.Show("Please enter your login details");
                }
                else
                {

                    SqlCommand cmd = new SqlCommand("sp_role_login", db.con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    db.con.Open();
                    cmd.Parameters.AddWithValue("@uname", textBox1.Text);
                    cmd.Parameters.AddWithValue("@upass", textBox2.Text);
                    SqlDataReader rd = cmd.ExecuteReader();

                    if (rd.HasRows)
                    {
                        
                        Dashboard d = new Dashboard();
                        Dashboard.instance.Label2.Text = "Booking cost for all movies 25zl";

                        string fileName = "Movies.txt";
                        string imageName = "Images.txt";

                        string filePath = Path.Combine(Directory.GetCurrentDirectory(), fileName);
                        string imagePath = Path.Combine(Directory.GetCurrentDirectory(), imageName);
                        d.DisplayTextFromFile(filePath, imagePath);
                        d.Show();
                    }
                    else
                    {
                        MessageBox.Show("                      " +
                            "Username or Password is incorrect\nPlease sign up if you do not have an account or use as guest");
                    }
                    db.con.Close();
                    clear();
                  
                }
                

            }
            catch (Exception)
            {

                MessageBox.Show("Unkown Error");
            }
            

        }
        void clear()
        {
            textBox1.Text = textBox2.Text = "";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Sign_Up sign = new Sign_Up();
            sign.ShowDialog();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Dashboard d = new Dashboard();

            string fileName = "Movies.txt";
            string imageName = "Images.txt";
            
            string filePath = Path.Combine(Directory.GetCurrentDirectory(), fileName); 
            string imagePath = Path.Combine(Directory.GetCurrentDirectory(), imageName);
            d.DisplayTextFromFile(filePath, imagePath);
            d.Show();


        }

        private void textBox1_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox1.Text))
            {
                errorProvider1.SetError(textBox1, "This field cannot be empty");
                e.Cancel = false;
            }
            else
            {

                errorProvider1.SetError(textBox1, "");
            }
        }

        private void textBox2_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox2.Text))
            {
                errorProvider1.SetError(textBox2, "This field cannot be empty");
                e.Cancel = true;
            }
            else
            {

                errorProvider1.SetError(textBox2, "");
            }
        }
    }
}
