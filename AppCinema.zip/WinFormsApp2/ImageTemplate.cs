﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace WinFormsApp2
{
    public partial class ImageTemplate : UserControl
    {
        public Image Poster
        {
            get { return this.poster.Image; }
            set { this.poster.Image = value; }

        }

        public ImageTemplate()
        {
            InitializeComponent();
        }
    }
}
