﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Text.RegularExpressions;

namespace WinFormsApp2
{
    public partial class Dashboard : Form
    {
        public static Dashboard instance;
        public Label Label2;

        public Dashboard()
        {
            InitializeComponent();
            instance = this;
            Label2 = costlabel2;

        }
 
        public void DisplayTextFromFile(string filePath, string imagePath)
        {
            
            try
            {
                StreamReader read = new StreamReader(filePath);

                int count = int.Parse(read.ReadLine());
                string[] movie = new string[count];
                string[] time = new string[count];
                string[] date = new string[count];


                for (int i = 0; i < count; i++)
                {
                    try
                    {
                        Template uc = new Template(i);
                        string line = read.ReadLine();
                        string[] elements = line.Split(';');
                        movie[i] = elements[0];
                        time[i] = elements[1];
                        date[i] = elements[2];

                        uc.Title = movie[i];
                        uc.Time = "Date: " + date[i] + "\nTime: " + time[i];

                        uc.ReservationClick += reservation_Click;

                        this.flowLayoutPanel2.Controls.Add(uc);
                    }
                    catch (Exception e)
                    {

                        MessageBox.Show(e.Message);
                    }
       
                }

                string line2;
                using (var sr = new StreamReader(imagePath))
                {
                    line2 = sr.ReadLine();
                }

                //string[] fotos;
                //fotos = line2.Split(';');

                //foreach (var item in fotos)
                //{
                //    ImageTemplate it = new ImageTemplate();
 
                //    this.flowLayoutPanel3.Controls.Add(it);
                //    it.Poster = Image.FromFile(item);

                //}

                string imageDirectory = "images";
                string[] imageFiles = Directory.GetFiles(imageDirectory, "*.jpeg");

                foreach (string imageFile in imageFiles)
                {
                    ImageTemplate pictureBox = new ImageTemplate();
                    this.flowLayoutPanel3.Controls.Add(pictureBox);
                    pictureBox.Poster = Image.FromFile(imageFile);

                }

            }
            catch (IOException ex)
            {
                MessageBox.Show("Error reading file: " + ex.Message);
            }
        }

        private void reservation_Click(object sender, EventArgs e)
        {

            {
                var button = (Button)sender;
              
                //button.Tag = i;
                var identifier = (int)button.Tag;
                var form = new BookTime(identifier);
                form.ShowDialog();
             
            }
            
          
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {

            Sign_Up sign = new Sign_Up();
            sign.Show();
            this.Hide();
        }
       

        private void vScrollBar1_ValueChanged_1(object sender, EventArgs e)
        {
            flowLayoutPanel3.VerticalScroll.Value = vScrollBar1.Value;
            flowLayoutPanel2.VerticalScroll.Value = vScrollBar1.Value;
            vScrollBar1.ValueChanged += vScrollBar1_ValueChanged_1;
        }

        private void vScrollBar1_Scroll_1(object sender, ScrollEventArgs e)
        {
            flowLayoutPanel3.VerticalScroll.Value = vScrollBar1.Value;
            flowLayoutPanel2.VerticalScroll.Value = vScrollBar1.Value;
        }
    }
}
