﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace WinFormsApp2
{
    public partial class Template : UserControl
    {

        public string Title
        {
            get { return this.title.Text; }
            set { this.title.Text = value; }
        }
        public string Time
        {
            get { return this.times.Text; }
            set { this.times.Text = value; }
        }

        public event EventHandler ReservationClick;

        public Template(int id)
        {
            InitializeComponent();
            this.button1.Tag = id;

        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (ReservationClick != null)
            {
                ReservationClick(sender, e);

            }

        }
    }
}
